#ifndef _math_H
#define _math_H

#include <xc.h>
#include <stdio.h>

#define _XTAL_FREQ 64000000 //note intrinsic _delay function is 62.5ns at 64,000,000Hz  

int project_minmax(int x, int actual_min, int actual_max, 
                        int target_min, int target_max);

#endif
