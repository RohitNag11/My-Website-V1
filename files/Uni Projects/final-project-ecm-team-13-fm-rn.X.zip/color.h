#ifndef _color_H
#define _color_H

#include <xc.h>
#include <stdio.h>
#include <stdbool.h> 

#define _XTAL_FREQ 64000000 //note intrinsic _delay function is 62.5ns at 64,000,000Hz  

typedef struct colour_Data {
    //definition of RGBC structure:
    int R;
    int G;
    int B;
    int C;
    //index of predicted colour:
    unsigned int detected_colour;
} Colour_data;

typedef struct colour_Calib {
    //definition of RGB calibration values structure:
    int R_min;
    int G_min;
    int B_min;
    int R_max;
    int G_max;
    int B_max;
    int optimal_Clear_Val;
} Colour_calib;

#define Colour_min 0    //define colour channel output min
#define Colour_max 100  //define colour channel output max
//#define optimal_Clear_Val 6000  /*define value of optimal clear channel
//                                 *at which buggy reads colours*/
#define leeway 5    //amount of float within optimal value allowed

/********************************************//**
 *  Function to initialise the colour click module using I2C
 ***********************************************/
void colour_click_init(void);

/********************************************//**
 *  Function to write to the colour click module
 *  address is the register within the colour click to write to
 *	value is the value that will be written to that address
 ***********************************************/
void colour_writetoaddr(char address, char value);

/********************************************//**
 *  Function to read the red channel
 *	Returns a 16 bit ADC value representing colour intensity
 ***********************************************/
unsigned int colour_read_Red(unsigned int calib_const);

/********************************************//**
 *  Function to read the green channel
 *	Returns a 16 bit ADC value representing colour intensity
 ***********************************************/
unsigned int colour_read_Green(unsigned int calib_const);

/********************************************//**
 *  Function to read the blue channel
 *	Returns a 16 bit ADC value representing colour intensity
 ***********************************************/
unsigned int colour_read_Blue(unsigned int calib_const);

/********************************************//**
 *  Function to read the clear channel
 *	Returns a 16 bit ADC value representing colour intensity
 ***********************************************/
unsigned int colour_read_Clear(unsigned int calib_const);


/********************************************//**
 *  Function to read all color channel values and
 *  change values in input structure
 ***********************************************/
Colour_data* colour_read_All(Colour_data *colour_data);
Colour_data* colour_map_All(Colour_data *colour_data, Colour_calib *colour_calib);
/********************************************//**
 *  Function to store all color channel values
 *  in input structure into input buffer
 ***********************************************/
void store_raw_colours(char *ColourToSend, Colour_data *colour_data);
void store_mapped_colours(char *ColourToSend, Colour_data *colour_data, Colour_calib *colour_calib);

/********************************************//**
 *  Function to calibrate the photodiode to lighting condition
 *  stores min and max values for each colour channel
 ***********************************************/
void calib_colour(unsigned char *startup, char *CalibToSend, Colour_data *colour_data, Colour_calib *colour_calib);


/********************************************//**
 *  Function to check if in correct range
 *  lights up LED1 if too close and LED2 if too far
 *  lights up both if in correct range.
 *  returns a boolean which is 1 when in correct range.
 ***********************************************/
bool distance_check(Colour_calib *colour_calib);

/********************************************//**
 * Function to identify the colours from the RGB readings from unknown card
 * Data analysis through serial communication for accurate numbers
 * Outputs whether it is too close, too far, or the correct colour.
 ***********************************************/

void colour_identify(char *ColourToSend, Colour_data *colour_data, Colour_calib *colour_calib);
#endif