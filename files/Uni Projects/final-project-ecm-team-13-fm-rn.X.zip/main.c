//_____________________________CONFIGURATIONS__________________________________
// CONFIG1L:
#pragma config FEXTOSC = HS         /*External Oscillator mode Selection bits
                                     * (HS (crystal oscillator) above 8 MHz;
                                     * PFM set to high power)*/
#pragma config RSTOSC = EXTOSC_4PLL /*Power-up default value for COSC bits 
                                     * (EXTOSC with 4x PLL, with EXTOSC 
                                     * operating per FEXTOSC bits)*/

// CONFIG3L:
#pragma config WDTCPS = WDTCPS_31   /*WDT Period Select bits (Divider ratio 
                                     * 1:65536; software control of WDTPS)*/
#pragma config WDTE = OFF           /*WDT operating mode 
                                     * (WDT enabled regardless of sleep)*/
//Import Header Files:
#include <xc.h>             //access xc.8 compiler
#include <stdbool.h>        //import boolean library
#include "dc_motor.h"       //import dcmotor header file
#include "color.h"          //import colour header file
#include "serial.h"         //import serial header file
#include "lights.h"         //import lights header file
#include "math.h"           //import math header file
#include "interrupts.h"     //import interrupts header file
#include "timers.h"         //import timers header file

#define _XTAL_FREQ 64000000         /*note intrinsic _delay function is 62.5ns 
                                     *at 64,000,000Hz*/  
//_____________________________________________________________________________

void main(void){
    //________________________MODULE INITIALISATIONS___________________________
    colour_click_init();    //Initialise Colour detection
    initUSART4();   //Initialise serial communication
    lights_init();  //initialise lights on buggy
    battery_init(); //initialise battery readings
    //Timer0_init();
    initDCmotorsPWM(PWMcycle); 
    //_________________________________________________________________________
     
    //________________________STRUCTURE DEFINITIONS____________________________
    struct DC_motor motorL, motorR; //declare motor property structures:
    init_LeftMotor(&motorL);    //initial pins for left side motor
    init_RightMotor(&motorR);   //initial pins for right side motor
    
    //declare colour & colour calibration structures:
    Colour_data RGB_Data_Ptr;       /*declare a structure to store RGBC values
                                     *  and the detected colour*/
    Colour_calib RGB_Calib_Ptr;     /*declare a structure to store all 
                                     * calibration data values*/
    //_________________________________________________________________________
    
    //__________________________VARIABLE DEFINITIONS___________________________
    char buf[80];   //define a buffer to store values as a string
    unsigned char startup = 1;  //variable to define start state of buggy
    unsigned int optimal_clear = RGB_Calib_Ptr.optimal_Clear_Val;
    unsigned int colour_memory[100];/*declare a static array to store read
                                      * colour values (max 100 ints)*/
    unsigned int time_memory[100];  /*declare a static array to store time
                                      * values between cards (max 100 ints)*/
    unsigned int memory_index = 0;  /*declare a variable to store position 
                                      * of memory arrays*/
    //_________________________________________________________________________

    //    
    //__________________________CALIBRATION SEQUENCES__________________________
    //BUGGY WORKS BEST WITHOUT TYRES
    /*Turning Calibration:
    * 1. Place robot on ground
    * 2. Allow buggy to rotate.
    * 3. Press button RF3 when robot exactly completes a full rotation
     */
    unsigned int turnConstantL; //define left turning calibration coefficient
    unsigned int turnConstantR; //define left turning calibration coefficient
    
    //function to set the turn-constant values:
    calib_turn(&turnConstantL, &turnConstantR, &motorL, &motorR);   
    
    /*Colour Calibration:
    //BUGGY WORKS BEST IN DARK (MINING) CONDITIONS
    //FOR OPTIMAL COLOUR DETECTION USE A 2X2.5X3 CM BLACK BOX AROUND LIGHTSENSOR
    * 1. Buggy will flash blue light.
    * 2. Bring dark blue card to about 3cm in front of the photodiode
    * 3. Press button RF2 to register the value.
    * 4. Buggy will flash the required colour to show.
    * 5. Bring required card in front of the photodiode to the correct range
        *  as indicated by LED1 and LED2 on the clicker board. 
        *  (Both LEDs light up if within correct range.)
    * 6. Press button RF2 to register the value.
    * 7. Repeat steps 4-6 for green, red and light blue cards.
    * 8. Buggy will display rainbow of colour after completion
    * NOTE: if button is pressed at the wrong distance, buggy will
    *       flash the required colour again.
     */
    //function to set the colour calibration constants:
    calib_colour(&startup, buf, &RGB_Data_Ptr, &RGB_Calib_Ptr);
    int C_opt = RGB_Calib_Ptr.optimal_Clear_Val;    /*store optimal-clear-value
                                                     * constant from Calib_Data
                                                     * structure in a shorter
                                                     * variable, C_opt*/
    //_________________________________________________________________________
    
    //_____________________________PRE-RUN SETUPS______________________________
    RGB_emit(0b111);    //emit white light from tri-colour rgb
    stop(&motorL, &motorR);     //stop the motor first
    __delay_ms(2000);   /*2s of delay after calibration before interrupts start
                         * triggering*/
    Interrupts_init(C_opt); /*initialise interrupts using correct threshold for
                             * photodiode*/
    Timer0_init();  //Initialise timers
    __delay_ms(1000);   //small delay before starting run
    seconds_counter=0;  //start seconds counter
    //_________________________________________________________________________

    
    while(1){
        int battery = battery_getval(); //get value of battery as a percentage
        sendIntSerial4(buf, battery); //send battery to PC to check value.
        
        //_______________________IF CARD IS DETECTED...________________________
        if (stopforcard == 1)   //if interrupt is triggered...
        {
            /*store time taken between a card detection and the interrupt to 
             * get triggered inside time_memory array:*/
            time_memory[memory_index] = seconds_counter;
            stop(&motorL, &motorR);     //stop motors
            RGB_emit(0b111);    //emit white light
            
//            sendIntSerial4(buf, C_opt);     /*send optimal clear channel value
//                                             * to PC to check*/
            __delay_ms(1000);   //1s delay before reading colour values
            
            //READ COLOUR VALUES....
            store_raw_colours(buf, &RGB_Data_Ptr);  //reads raw channel values
            int C = RGB_Data_Ptr.C; /*store actual clear channel value from
                                     * structure in shorter variable C*/
//            sendIntSerial4(buf, C); //send actual clear channel value to PC
            
            //AUTO POSITION BUGGY...
            //go inside while loop if out of range and auto-calibrate position:
            while ((C > (C_opt + leeway)) || (C < (C_opt + leeway))){  
                //if too far:
                if (C < (C_opt - leeway)){
                    LED1 = 1;   
                    LED2 = 0;
                    //give a forward pulse:
                    pulseStraight(&motorL, &motorR, 1);
                    __delay_ms(50);     //pause before reading values
                    store_raw_colours(buf, &RGB_Data_Ptr);//reread colour values
                    C = RGB_Data_Ptr.C; //change c value
                }
                //if too close:
                else if (C > (C_opt + leeway)){
                    LED1 = 0;
                    LED2 = 1;
                    //give a backwards pulse
                    pulseStraight(&motorL, &motorR, 0);
                    __delay_ms(50);
                    store_raw_colours(buf, &RGB_Data_Ptr);//reread colour values
                    C = RGB_Data_Ptr.C; //change c value
                }
                //only exit white loop if in correct range:
                else {break;}
            }
            
            //ONCE IN CORRECT RANGE, IDENTIFY COLOUR...
            store_raw_colours(buf, &RGB_Data_Ptr);//read raw colour values again
            //map raw values to percentages:
            store_mapped_colours(buf, &RGB_Data_Ptr, &RGB_Calib_Ptr);
//            sendStringSerial4(buf); //send mapped RGBC values to PC
            colour_identify(buf, &RGB_Data_Ptr, &RGB_Calib_Ptr);/*identify
                                                                 *exact colour*/
//            sendStringSerial4(buf); //send detected colour to PC
            
            //store detected colour inside colour_memory array:
            colour_memory[memory_index] = RGB_Data_Ptr.detected_colour;
            
            //Send both colour and time memory arrays to pc to check:
//            for(unsigned int i=0; i < memory_index+1; i++) { 
//                sendIntSerial4(buf, colour_memory[i]);
//                sendIntSerial4(buf, time_memory[i]);
//            }
            
            //perform specific instruction based on detected colour:
            colour_turn(0, RGB_Data_Ptr.detected_colour, &turnConstantL, 
                    &turnConstantR, &motorL, &motorR); /*perform instruction 
                                                        * based on detected 
                                                        * colour*/
            //actively check if traceback is needed:
            traceback(memory_index, colour_memory, time_memory, 
                            &turnConstantL, &turnConstantR, &motorL, &motorR);
            
            ResetInterrupt();   //reset interrupt flag
            memory_index++;     //increment memory index
            seconds_counter = 0;    /*reset timer counter before looking for
                                     * new card*/
        }//____________________________________________________________________
        
        //________________________IF NO CARD PRESENT...________________________
        //turn off both lights when not trying to detect a colour:
        LED1 = 0;
        LED2 = 0;
        ResetInterrupt();   //reset interrupt flag
        goStraight(&motorL, &motorR, 1);   //move forwards constantly
        store_raw_colours(buf, &RGB_Data_Ptr);  //read colour values
        sendIntSerial4(buf, C_opt);   //send required clear channel value to PC
        sendIntSerial4(buf, RGB_Data_Ptr.C);    /*send exact clear channel value
                                                 * to PC to check*/
        __delay_ms(1000);   //move forward in 1s intervals
    }//________________________________________________________________________
}
