#ifndef _lights_H
#define _lights_H

#include <xc.h>
#include <stdbool.h> 

#define _XTAL_FREQ 64000000 //note intrinsic _delay function is 62.5ns at 64,000,000Hz  

//Define Pins associted to each light:
#define LED1 LATDbits.LATD7
#define LED2 LATHbits.LATH3
#define LEFT LATFbits.LATF0
#define RIGHT LATHbits.LATH0
#define FOG LATDbits.LATD3
#define HEAD LATHbits.LATH1
#define BRAKE LATDbits.LATD4
#define BUTTON1 PORTFbits.RF2
#define BUTTON2 PORTFbits.RF3
//Functions:
void lights_init(void);
void LED_1(bool on);
void LED_2(bool on);
void leftsignal(bool on);
void rightsignal(bool on);
void MBeam(bool on);
void HLamp(bool on);
void Brake(bool on);
void RGB_emit(unsigned char RGB);
void RGB_flash(unsigned char RGB, unsigned char n);
void RGB_cycle(unsigned char n);
#endif