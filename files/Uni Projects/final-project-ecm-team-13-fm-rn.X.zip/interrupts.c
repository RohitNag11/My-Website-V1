#include <xc.h>
#include "interrupts.h"
#include "color.h"
#include "dc_motor.h"
#include "i2c.h"
#include "timers.h"
#include "lights.h"

/************************************
 * Function to turn on interrupts and set if priority is used
************************************/
void Interrupts_init(unsigned int optimal_clear)
{
    //turn on device interrupt. 0b10011 to keep others on too.
    colour_writetoaddr(0x00, 0x13);
    
    //set RGBC interrupt threshold registers
    //never want it to interrupt below certain value
    colour_writetoaddr(0x04, 0x00);//AILTL
    colour_writetoaddr(0x05, 0x00); //AILTH
   
    //use calibrated values for upper threshold
    colour_writetoaddr(0x06, optimal_clear && 11111111); //AIHTL
    colour_writetoaddr(0x07, optimal_clear >> 8);//AIHTH
    
    //set persistence register.
    colour_writetoaddr(0x0C, 0b0001);//interrupts when 1 consecutive values out of range
    
    
    //initialise microbus 1
    PIR0bits.INT0IF=0; //set to initial state (no interrupt)
    
    PIE0bits.INT0IE=1; // enable external interrupt
    PIE0bits.TMR0IE = 1; //enable bit timer0 interrupts
    
    INTCONbits.PEIE=1; //turn on peripheral interrupts
    INTCONbits.INT0EDG=0; //external interrupt set to falling edge of INTx pin
    INTCONbits.IPEN=1;  //turn on priority interrupts
    
    INT0PPSbits.PORT = 001; // Port B 
    INT0PPSbits.PIN = 000; // RB0 - INT1 on pickit
    TRISBbits.TRISB0 = 1; // activate mikrobus 1 INT pin
    ANSELBbits.ANSELB0 = 0; // disable RB0 analogue input
    
    IPR0bits.INT0IP = 0; //set priority of peripheral interrupt to low
    IPR0bits.TMR0IP = 1; //set priority of timer0 interrupt to high
    
    INTCONbits.GIE=1; //turn on interrupts globally
}

   
//function to clear the interrupt when process is complete
void ClearInterrupt(void){
    I2C_2_Master_Start(); // Start condition
    I2C_2_Master_Write(0x52 | 0x00); // 7 bit address + Write mode
    I2C_2_Master_Write(0xE6); // command to clear interrupt
    I2C_2_Master_Stop(); // Stop condition
}

//function to reset interrupt and other variables
void ResetInterrupt(void) {
    ClearInterrupt(); // clear interrupt
    stopforcard = 0; // reset stopforcard to 0
    BRAKE = 0; // reset LED
    INTCONbits.PEIE = 1; //re-enable peripheral interrupts 
}

/************************************
 * Low priority interrupt service routine - triggers at optimal clear value
        to stop buggy at roughly correct distance form crd
 * Make sure all enabled interrupts are checked and flags cleared
************************************/
void __interrupt(low_priority) ColourISR()
{
    if (PIR0bits.INT0IF){
        PIR0bits.INT0IF=0; //reset flag
        INTCONbits.PEIE=0; //disable peripheral interrupts
        BRAKE=1; //show interrupt is reached through LED
        stopforcard=1; //set a variable
    }
}

/************************************
 * High priority interrupt service routine - triggers every timer overflow
 * Make sure all enabled interrupts are checked and flags cleared
************************************/
void __interrupt(high_priority) TimerISR()
{
    if (PIR0bits.TMR0IF){   //check the TMR0 interrupt flag is 1
                            //true when when timer0 overflows
        PIR0bits.TMR0IF = 0; //clear the timer0 interrupt flag
        seconds_counter ++;
        //set correct counter start position after every overflow:
        TMR0H = start_high;   
        TMR0L = start_low;
//        HEAD=!HEAD; //switch state of headlights every time timer overflows
    }
}

