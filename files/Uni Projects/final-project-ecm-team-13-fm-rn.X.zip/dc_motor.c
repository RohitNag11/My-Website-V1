#include <xc.h>
#include "dc_motor.h"
#include "lights.h"
#include "color.h"

//function initialise T2 and PWM for DC motor control
void initDCmotorsPWM(int PWMperiod){
	//initialise your TRIS and LAT registers for PWM
     TRISEbits.TRISE2=0; //set RE2 as output
     TRISCbits.TRISC7=0; //set RC7 as output
     
     LATEbits.LATE2=0; //Set initial output state for RE2
     LATCbits.LATC7=0; //Set initial output state for RC7
     
     TRISEbits.TRISE4=0; //set RE2 as output
     TRISGbits.TRISG6=0; //set RC7 as output
     
     LATEbits.LATE4=1; //Set initial output state for RE2
     LATGbits.LATG6=1; //Set initial output state for RC7
    // timer 2 config
     //For frequency 10kHz, PS=16 for 8 bit timer
    T2CONbits.CKPS=0b100; // 1:16 prescaler
    T2HLTbits.MODE=0b00000; // Free Running Mode, software gate only
    T2CLKCONbits.CS=0b0001; // Fosc/4

    // Tpwm*(Fosc/4)/prescaler - 1 = PTPER
    //(0.0001s)*((64MHz/4)/16)-1=99
    T2PR=99; //Period reg 10kHz base period
    T2CONbits.ON=1;
    
    RE2PPS=0x0A; //PWM6 on RE2
    RC7PPS=0x0B; //PMW7 on RC7

    PWM6DCH=0; //0% power
    PWM7DCH=0; //0% power
    
    PWM6CONbits.EN = 1;
    PWM7CONbits.EN = 1;
}


// function to set PWM output from the values in the motor structure
void setMotorPWM(struct DC_motor *m)
{
	int PWMduty; //tmp variable to store PWM duty cycle

	if (m->direction){ //if forward
		// low time increases with power
		PWMduty=m->PWMperiod - ((int)(m->power)*(m->PWMperiod))/100;
	}
	else { //if reverse
		// high time increases with power
		PWMduty=((int)(m->power)*(m->PWMperiod))/100;
	}

	*(m->dutyHighByte) = PWMduty; //set high duty cycle byte
        
	if (m->direction){ // if direction is high
        // set dir_pin bit in LAT to high without changing other bits
		*(m->dir_LAT) = *(m->dir_LAT) | (1<<(m->dir_pin)); 
	} else {
        // set dir_pin bit in LAT to low without changing other bits
		*(m->dir_LAT) = *(m->dir_LAT) & (~(1<<(m->dir_pin))); 
	}
}

//function to initial pins for left side motor:
void init_LeftMotor(struct DC_motor *m)
{
    m->power=0; //Set power as 0 to start
    m->direction=1; //default motor direction
    m->dutyHighByte=(unsigned char *)(&PWM6DCH); //Store address of PWM duty high byte
    m->dir_LAT=(unsigned char *)(&LATE); //store address of LAT
    m->dir_pin=4;//pin RE4 controls direction for motorL
    m->PWMperiod=PWMcycle;//store PWMperiod for motor
}

//function to initial pins for right side motor:
void init_RightMotor(struct DC_motor *m)
{
    m->power=0; //Set power as 0 to start
    m->direction=1; //default motor direction
    m->dutyHighByte=(unsigned char *)(&PWM7DCH); //Store address of PWM duty high byte
    m->dir_LAT=(unsigned char *)(&LATG); //store address of LAT
    m->dir_pin=6;//pin RE4 controls direction for motorL
    m->PWMperiod=PWMcycle;//store PWMperiod for motor
}

//function to stop the robot gradually.
//changed to have both wheels stop at the same time always, even when turning
void stop(struct DC_motor *mL, struct DC_motor *mR)
{
    /*Use constant decrements to reduce power at same rate, even if wheels
     * are spinning at different speeds*/
    unsigned int decL= (mL->power)/10; //decrement for left side, power/10
    unsigned int decR= (mR->power)/10; //decrement for right side, power/10

    while (mL->power > 0){ //while either side is spinning
        mL->power= mL->power - decL;    //decrement left motor power
        mR->power= mR->power - decR;    //decrement right motor power
        setMotorPWM(mL);    //set left motor PWM output
        setMotorPWM(mR);    //set right motor PWM output
        __delay_ms(5); //small delay to make increment smoother (less strain on motors)
    }
    mL->power = 0;  //if power is at 0, power stays at 0
    mR->power = 0;  //if power is at 0, power stays at 0
    
    setMotorPWM(mL);    //set left motor PWM output
    setMotorPWM(mR);    //set right motor PWM output
    Brake(0);   //turn off brake light
}


//function to make the robot turn right 
//considering the power differences for backwards turning (lower forward power)
//Outputs small pulses of rotation to turn on the spot.
void turnRight(struct DC_motor *mL, struct DC_motor *mR)
{ 
    stop(mL,mR); //stop previous function
    mR->direction = 0;  //set left wheels to roll backwards
    mL->direction = 1;  //set right wheels to roll forwards
    while (mR->power < 60){ //until it reaches speed
        mR->power=mR->power+20; //increment backwards motor power (right)
        mL->power=mL->power+10; //increment forwards power (left) 
        setMotorPWM(mR);    //set left motor PWM output
        setMotorPWM(mL);    //set right motor PWM output
        rightsignal(1); //turn on right indicator 
        __delay_ms(5); //small delay to make increment smoother
    }
    rightsignal(0); //turn off right indicator 
    __delay_ms(1); //delay for length of turn
    stop(mL,mR); //stop once done
}

//function to make the robot turn left
//considering power differences for backward turning (lower forward power)
//Outputs small pulses of rotation to turn on the spot.
void turnLeft(struct DC_motor *mL, struct DC_motor *mR)
{
    stop(mL,mR); //stop previous function
    mL->direction = 0;  //set left wheels to roll backwards
    mR->direction = 1;  //set right wheels to roll forwards
    while (mL->power < 60){ //until it reaches speed
        mL->power=mL->power+20; //increment backwards motor power (left)
        mR->power=mR->power+10; //increment forwards power (right) 
        setMotorPWM(mL);    //set left motor PWM output
        setMotorPWM(mR);    //set right motor PWM output
        leftsignal(1);  //turn on left indicator 
        __delay_ms(5); //small delay to make increment smoother
    }
    leftsignal(0);  //turn off left indicator 
    __delay_ms(1); //delay for length of turn
    stop(mL,mR); //stop once done
    
}
//function to have easily adjustable angle and direction of turning within code
//initial inputs are to control separate motors
/*requires input of direction (0:Left, 1:Right), the required angle (degrees) 
 * and the turning calibration constant.*/
void turnAngle(struct DC_motor *mL,struct DC_motor *mR, unsigned int direction, 
        unsigned int angle, unsigned int *turnConstantL, unsigned int *turnConstantR)
{
    //simple equation to calculate how many turn pulses are needed
    //(pulses needed per full rotation) / 360 = (pulses per degree)
    //(pulses per degree) x degree = (required amount of pulses)
    //Uses separate functions and turn constants due to motor imbalances
    
    if (direction==0){//Left
        unsigned int pulses=(((*turnConstantL)*angle)/360);
        for (int i=0; i<pulses; i++) { // uses left turn function to turn left for defined number of pulses
            turnLeft(mL, mR); //use turn function
            __delay_ms(50);} //delay to slow down and keep consistent turning (no slip)
    }
    else if (direction==1){//Right
        unsigned int pulses2=(((*turnConstantR)*angle)/360);
         for (int i=0; i<pulses2; i++) { // uses left turn function to turn left for defined number of pulses
             turnRight(mL, mR); //use turn function
             __delay_ms(50);} //delay to slow down and keep consistent turning (no slip)
        }
    }

//function to make the robot go straight; forwards or backwards continously
//direction = 1 if forwards. direction = 0 if backwards.
void goStraight(struct DC_motor *mL, struct DC_motor *mR, bool dir)
{
    unsigned int power;
    if (dir){power = 20;} //set lower power for forwards movement (faster motor)
    else {power = 50;}
    mR->direction = dir;  //set right wheels to roll forwards(1) or backwards(0)
    mL->direction = dir;  //set left wheels to roll forwards(1) or backwards(0)
    //to avoid abrupt motor starting
    while (mR->power < power){
        mR->power ++;  //slowly increase power output for right wheels
        mL->power ++;  //slowly increase power output for left wheels
        setMotorPWM(mL);    //set left motor PWM output
        setMotorPWM(mR);    //set right motor PWM output
        __delay_ms(5); //small delay to make increment smoother
        //MBeam(1);   //Turn on fog beam
    }
    mL->power = power;  //if power is at 100, power stays at 100
    //mL->power = power-2; //Adjusted value for Frederik due to curving buggy
    mR->power = power;  //if power is at 100, power stays at 100
//    MBeam(0);   //Turn off fog beam
    setMotorPWM(mL);    //set left motor PWM output
    setMotorPWM(mR);    //set right motor PWM output
}

//function to make the robot go straight, forwards or backwards in small pulses
//used to accurately locate buggy with respect to cards.
//direction = 1 if forwards. direction = 0 if backwards.
void pulseStraight(struct DC_motor *mL, struct DC_motor *mR, bool dir)
{
    unsigned int power;
    if (dir){power = 10;} //low power to make small pulses
    else {power = 50;} //also low (backwards has less power)
    mL->direction = dir;  //set left wheels to roll forwards(1) or backwards(0)
    mR->direction = dir;  //set right wheels to roll forwards(1) or backwards(0)
    //to avoid abrupt motor starting
    while (mL->power < power){
        mL->power ++;  //slowly increase power output for left wheels
        mR->power ++;  //slowly increase power output for right wheels
        setMotorPWM(mL);    //set left motor PWM output
        setMotorPWM(mR);    //set right motor PWM output
        //change delay depending on direction due to power differences
        if (dir){
            __delay_ms(10);}
        else {
            __delay_ms(1);} //small delay to make increment smoother    
    }
    stop(mL,mR); //stop for pulse
    setMotorPWM(mL);    //set left motor PWM output
    setMotorPWM(mR);    //set right motor PWM output
    
    
}

/*turning calibration. Count how many pulses for robot to do full turn.
 Required to calibrate for both sides due to differences in motors */
void calib_turn( unsigned int *turnConstantL, unsigned int *turnConstantR, 
        struct DC_motor *mL, struct DC_motor *mR)
{
    stop(mL,mR);
    //Left side turn first
    __delay_ms(1500);   //time to put buggy on the floor
    *turnConstantL = 0;  //reset calibration constant
    for (int i=0; i<300; i++) { //causes rotation for a maximum 300 pulses
        (*turnConstantL)++;  //increment turn constant, saves number of pulses
        turnLeft(mL, mR); //Cause left pulsation
        __delay_ms(20);
        BRAKE = 1;
        if (!BUTTON2){
            i = 400;    //if button is pressed exit if loop
        }
    }
    RGB_cycle(3);   //show disco lights once complete
    
    //Right side turn
    __delay_ms(1500);   
    *turnConstantR = 0;  //reset calibration constant
    for (int j=0; j<300; j++) { //causes rotation for a maximum 300 pulses
        (*turnConstantR)++;  //increment turn constant, saves number of pulses
        turnRight(mL, mR); //Cause right pulsation
        __delay_ms(20);
        BRAKE = 1;
        if (!BUTTON2){
            j = 400;    //if button is pressed exit if loop
        }
    }
    RGB_cycle(3);   //show disco lights once complete
    __delay_ms(1500); 
}

/*Function to turn the car depending on the colour seen*/
//Traceback: mode = 1, normal: mode = 0,
//Traceback causes opposite rotation
void colour_turn(bool mode, int colour,  unsigned int *turnConstantL, 
        unsigned int *turnConstantR, struct DC_motor *mL, struct DC_motor *mR)
{
    
    if (colour == 0){   //if colour is red turn 90 degrees clockwise
        turnAngle(mL, mR, !mode, 90, turnConstantL, turnConstantR);
    } 
    else if (colour == 1){   //if colour is pink turn 60 degrees clockwise
        turnAngle(mL, mR, !mode, 60, turnConstantL, turnConstantR);
    }
    else if (colour == 2){   //if colour is orange turn 30 degrees anticlockwise
        turnAngle(mL, mR, mode, 30, turnConstantL, turnConstantR);
    }
    else if (colour == 3){   //if colour is yellow turn 30 degrees clockwise
        turnAngle(mL, mR, !mode, 30, turnConstantL, turnConstantR);
    }
    else if (colour == 4){   //if colour is light green turn 135 degrees anticlockwise
        turnAngle(mL, mR, mode, 135, turnConstantL, turnConstantR);
    }
    else if (colour == 5){   //if colour is dark green turn 90 degrees anticlockwise
        turnAngle(mL, mR, mode, 90, turnConstantL, turnConstantR);
    }
    else if (colour == 6){   //if colour is light blue turn 180 degrees
        turnAngle(mL, mR, !mode, 180, turnConstantL, turnConstantR);
    }
    else if (colour == 7){   //if colour is dark blue turn 60 degrees anticlockwise
        turnAngle(mL, mR, mode, 60, turnConstantL, turnConstantR);
    }
    else if (colour == 8){   //if colour is purple turn 135 degrees clockwise
        turnAngle(mL, mR, !mode, 135, turnConstantL, turnConstantR);
    }
    else if (colour == 9){  //if colour is black turn on disco
        RGB_cycle(4);
        RGB_emit(0b111);
        goStraight (mL, mR, 0); //go backwards  a bit to not hit card when rotating
        __delay_ms(150);
        stop(mL, mR);
        //need to call trace back function here (later functions)
    }
    else {RGB_flash(0b111,3);} //if no colour is detected flash white 3 times
}

/*Function to make buggy traceback original path.*/
void traceback(unsigned int memory_index, unsigned int colour_memory[], 
                    unsigned int time_memory[],  unsigned int *turnConstantL, unsigned int *turnConstantR, 
                                    struct DC_motor *mL, struct DC_motor *mR)
{
    //if black card detected or the buggy has not detected a card for over 2 minutes (lost)
    if ((colour_memory[memory_index] == 9)||(time_memory[memory_index] > 1200)) {  
        turnAngle(mL, mR, 0, 180, turnConstantL, turnConstantR);    //turn around 180 degrees
        /*go backwards to ensure correct starting position (due to moving away
         * from black card first)*/
        goStraight (mL, mR, 0); 
        __delay_ms(150); //same distance as move back from black card
        char i = memory_index;  //set variable to equal length of memory arrays
        unsigned int j;
        
        for (i; i-- > -1;) { //travel backwards through array
            goStraight(mL, mR, 1);
            for (j = 0; j < time_memory[i+1]; j++){ //a delay equivalent to timer_memory[i]
                __delay_ms(100); /*ensures same distance traveled, time memory increments
                                     every 100ms*/
            }
            stop(mL, mR);   //stop motor
            colour_turn(1, colour_memory[i], turnConstantL, turnConstantR, mL, mR); //carry out colour turn instructions in traceback mode
        }
        stop(mL, mR);   //keep motor stopped for 6s after completing traceback
        __delay_ms(1000);
        __delay_ms(1000);
        __delay_ms(1000);
        __delay_ms(1000);
        __delay_ms(1000);
        __delay_ms(1000);
    }
}

//Battery readings taken to provide calibration with power of motors
// Problems with real term constantly displaying same value meant limited use.
/*initialise battery value reading*/
void battery_init(void){
     TRISFbits.TRISF6=1; //set RF6 as input for battery level
     ANSELFbits.ANSELF6=1; //turn on analogue input
     
     //set up ADC module
     ADREFbits.ADNREF=0; //Use Vss (0V) as negative reference
     ADREFbits.ADPREF=0b00; //Use Vdd (3.3V) as positive reference
     ADPCH=0b101110; //Select channel RF6 for ADC
     ADCON0bits.ADFM=0; //Left justified result ie. no leading 0s
     ADCON0bits.ADCS=1; //Use internal fast RC (FRC) oscillator as clock source for conversion
     ADCON0bits.ADON=1; //Enable ADC
}
/*Return battery reading as a percentage*/
int battery_getval(void){
    int battery; //initialise battery as an integer
    ADCON0bits.GO=1; //Start ADC conversion
    while(ADCON0bits.GO); //Wait until conversion is done
    battery = ADRESH; //Get 8 most significant bits of ADC result (10 bit number))
    //battery=(battery*100)/255; //convert battery value to a percentage
    battery = (battery/(2^10 - 1))*3.3*3;
    return battery; //return battery value
}


