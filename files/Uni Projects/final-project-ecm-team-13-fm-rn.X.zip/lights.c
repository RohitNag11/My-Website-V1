#include <xc.h>
#include "lights.h"

//Initialise lights
void lights_init(void)
{
    TRISFbits.TRISF0=0; //set pin F0 to output
    TRISDbits.TRISD3=0; //set pin D3 to output
    TRISHbits.TRISH1=0; //set pin H1 to output
    TRISHbits.TRISH0=0; //set pin H0 to output
    TRISDbits.TRISD4=0; //set pin D4 to output
    TRISDbits.TRISD7 = 0;   //set pin D7 to output
    TRISHbits.TRISH3 = 0;   //set pin H3 to output
    TRISFbits.TRISF2 = 1;   //set pin F2 to input
    TRISFbits.TRISF3 = 1;   //set pin F3 to input
    TRISGbits.TRISG0=0; //RED pin 
    TRISEbits.TRISE7=0; //Green pin
    TRISAbits.TRISA3=0; //Blue pin
    
    ANSELFbits.ANSELF2=0; //turn off analogue input on pin
    ANSELFbits.ANSELF3=0; //turn off analogue input on pin
    
    LEFT=0;   //set pin F0 to low
    RIGHT=0;   //set pin H0 to low
    FOG=0;   //set pin D3 to low
    HEAD=0;   //set pin H1 to low
    BRAKE=0;   //set pin D4 to low
    LED1 = 0; //set pin D7 to high
    LED2 = 0;    //set pin F3 to high
}

//Function to turn on or off LED1 on the clicker board:
void LED_1(bool on) {LED1 = on;}

//Function to turn on or off LED2 on the clicker board:
void LED_2(bool on) {LED2 = on;}

//Function to turn on or off the Left indicators:
void leftsignal(bool on) {LEFT = on;}

//Function to turn on or off the Left indicators:
void rightsignal(bool on) {RIGHT = on;}

//Function to turn on or off the Fog Beams:
void MBeam(bool on) {FOG = on;}

//Function to turn on or off the Head Lamps:
void HLamp(bool on) {HEAD = on;}

//Function to turn on or off the Brake Tail lights:
void Brake(bool on) {BRAKE = on;}

//Function to set tricolor states on LED module:
void RGB_emit(unsigned char RGB)
{
    if (RGB & 0b100){LATGbits.LATG0=1;}
    else{LATGbits.LATG0=0;}
    
    if (RGB & 0b010){LATEbits.LATE7=1;}
    else{LATEbits.LATE7=0;}
    
    if (RGB & 0b001){LATAbits.LATA3=1;}
    else{LATAbits.LATA3=0;}
}

//Function to flash tricolor states on LED module, n times:
void RGB_flash(unsigned char RGB, unsigned char n)
{
    for (int i=1; i<n; i++)
    {
        RGB_emit(0b000);
        __delay_ms(100);
        RGB_emit(RGB);
        __delay_ms(100);
    }
    RGB_emit(0b000);
    __delay_ms(100);
    RGB_emit(0b111);
}

//Function to cycle tricolor states on LED module:
void RGB_cycle(unsigned char n)
{
    for (int i=1; i<n; i++)
    {
        RGB_emit(0b100);
        __delay_ms(100);
        RGB_emit(0b010);
        __delay_ms(100);
        RGB_emit(0b001);
        __delay_ms(100);
    }
    RGB_emit(0b000);
}