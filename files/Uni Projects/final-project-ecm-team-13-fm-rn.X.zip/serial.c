#include <xc.h>
#include "serial.h"
#include "color.h"

//Setting up Serial for data analysis and debugging

void initUSART4(void) {
    //code to set up USART4 for Reception and Transmission :
    RC0PPS = 0b010010;  /*Map EUSART4-TX to RC0 
                         *change to 0x12 if necessary: as stated in readme*/
    RX4PPS = 0b010001;  //Map EUSART4-RX to RC1
    TRISCbits.TRISC1 = 1; //Set RX pin (RC1) to input
    
    //Setting up EUSART4 to send/receive data asynchronously to/from the PC:
    BAUD4CONbits.BRG16 = 0; 	//set baud rate scaling
    TX4STAbits.BRGH = 0; 		//high baud rate select bit
    SP4BRGL = 51; 			//set baud rate to 51 = bps19200
    SP4BRGH = 0;			//not used

    RC4STAbits.CREN = 1; 		//enable continuous reception
    TX4STAbits.TXEN = 1; 		//enable transmitter
    RC4STAbits.SPEN = 1; 		//enable serial port
}

//function to wait for a byte to arrive on serial port and read it once it does 
char getCharSerial4(void) {
    while (!PIR4bits.RC4IF);//wait for the data to arrive
    return RC4REG; //return byte in RCREG
}

//function to check the TX reg is free and send a byte
void sendCharSerial4(char charToSend) {
    while (!PIR4bits.TX4IF); // wait for flag to be set
    TX4REG = charToSend; //transfer char to transmitter
}

//function to send a string over the serial interface
void sendStringSerial4(char *stringToSend){
    //combine all characters in input string and send together to PC:
    while (*stringToSend != 0){       
        sendCharSerial4(*stringToSend++); 
	}
}

//function to send an integer as decimal over the serial interface
void sendIntSerial4(char *intToSend, int integer)
{
    sprintf(intToSend, "%d\n\r", integer);
    sendStringSerial4(intToSend);
}
