#include <xc.h>
#include "color.h"
#include "i2c.h"
#include "lights.h"
#include "math.h"

//Function to initiate colour click module:
void colour_click_init(void)
{   
    //setup colour sensor via i2c interface:
    I2C_2_Master_Init();      //Initialise i2c Master
    
     //set device PON:
	 colour_writetoaddr(0x00, 0x01);
     
    __delay_ms(3); //need to wait 3ms for everthing to start up
    
//    //set integration time:
	colour_writetoaddr(0x01, 0xD5); /*Integration time = 101 ms, 
                                     * max RGBC count = 43008*/
    //set gain time:
	colour_writetoaddr(0x0F, 0b01); /*Gain = 4x*/   
    
    //turn on device ADC:
	colour_writetoaddr(0x00, 0x03);
}

//Function to write colour instructions to i2c address:
void colour_writetoaddr(char address, char value){
    I2C_2_Master_Start();         //Start condition
    I2C_2_Master_Write(0x52 | 0x00);     //7 bit device address + Write mode
    I2C_2_Master_Write(0x80 | address);    //command + register address
    I2C_2_Master_Write(value);    
    I2C_2_Master_Stop();          //Stop condition
}

//Function to read red channel value as an integer from photodiode:
unsigned int colour_read_Red(unsigned int calib_const)
{
	unsigned int tmp;
	I2C_2_Master_Start();         //Start condition
	I2C_2_Master_Write(0x52 | 0x00);     //7 bit address + Write mode
	I2C_2_Master_Write(0xA0 | 0x16);    //command (auto-increment protocol transaction) + start at RED low register
	I2C_2_Master_RepStart();			// start a repeated transmission
	I2C_2_Master_Write(0x52 | 0x01);     //7 bit address + Read (1) mode
	tmp=I2C_2_Master_Read(1);			//read the Red LSB
	tmp=tmp | (I2C_2_Master_Read(0)<<8); //read the Red MSB (don't acknowledge as this is the last read)
	I2C_2_Master_Stop();          //Stop condition
    //tmp = tmp * calib_const;
	return tmp;
}

//Function to read blue channel value as an integer from photodiode:
unsigned int colour_read_Blue(unsigned int calib_const)
{
	unsigned int tmp;
	I2C_2_Master_Start();         //Start condition
	I2C_2_Master_Write(0x52 | 0x00);     //7 bit address + Write mode
	I2C_2_Master_Write(0xA0 | 0x1A);    //command (auto-increment protocol transaction) + start at Blue low register
	I2C_2_Master_RepStart();			// start a repeated transmission
	I2C_2_Master_Write(0x52 | 0x01);     //7 bit address + Read (1) mode
	tmp=I2C_2_Master_Read(1);			//read the Red LSB
	tmp=tmp | (I2C_2_Master_Read(0)<<8); //read the Red MSB (don't acknowledge as this is the last read)
	I2C_2_Master_Stop();          //Stop condition
    //tmp = tmp * calib_const;
	return tmp;
}

//Function to read green channel value as an integer from photodiode:
unsigned int colour_read_Green(unsigned int calib_const)
{
	unsigned int tmp;
	I2C_2_Master_Start();         //Start condition
	I2C_2_Master_Write(0x52 | 0x00);     //7 bit address + Write mode
	I2C_2_Master_Write(0xA0 | 0x18);    //command (auto-increment protocol transaction) + start at Green low register
	I2C_2_Master_RepStart();			// start a repeated transmission
	I2C_2_Master_Write(0x52 | 0x01);     //7 bit address + Read (1) mode
	tmp=I2C_2_Master_Read(1);			//read the Red LSB
	tmp=tmp | (I2C_2_Master_Read(0)<<8); //read the Red MSB (don't acknowledge as this is the last read)
	I2C_2_Master_Stop();          //Stop condition
    //tmp=tmp*calib_const;
	return tmp;
}

//Function to read clear channel value as an integer from photodiode:
unsigned int colour_read_Clear(unsigned int calib_const)
{
	unsigned int tmp;
	I2C_2_Master_Start();         //Start condition
	I2C_2_Master_Write(0x52 | 0x00);     //7 bit address + Write mode
	I2C_2_Master_Write(0xA0 | 0x14);    //command (auto-increment protocol transaction) + start at CLear low register
	I2C_2_Master_RepStart();			// start a repeated transmission
	I2C_2_Master_Write(0x52 | 0x01);     //7 bit address + Read (1) mode
	tmp=I2C_2_Master_Read(1);			//read the Red LSB
	tmp=tmp | (I2C_2_Master_Read(0)<<8); //read the Red MSB (don't acknowledge as this is the last read)
	I2C_2_Master_Stop();          //Stop condition
    //tmp = tmp * calib_const;
	return tmp;
}

//PREMAP: Function to read all colour channel values and change input RGBC struct:
Colour_data* colour_read_All(Colour_data *colour_data)
{
    colour_data->R = colour_read_Red(1); //Store Red register value in R
    colour_data->G = colour_read_Green(1); //Store Green register value in G
    colour_data->B = colour_read_Blue(1); //Store Blue register value in B
    colour_data->C = colour_read_Clear(1); //Store Clear register value in C
    return colour_data; //return raw colour readings
}

/*MAPPING: Function to read all colour channel values and map target range
 *  and also change input RGBC struct:*/
Colour_data* colour_map_All(Colour_data *colour_data, Colour_calib *colour_calib)
{
    //Read raw colour values
    colour_data = colour_read_All(colour_data);
    
    //Map raw colour values as percentages
    colour_data->R = project_minmax(colour_data->R, colour_calib->R_min, 
                                    colour_calib->R_max, Colour_min, Colour_max);
    colour_data->G = project_minmax(colour_data->G, colour_calib->G_min, 
                                    colour_calib->G_max, Colour_min, Colour_max);
    colour_data->B = project_minmax(colour_data->B, colour_calib->B_min, 
                                    colour_calib->B_max, Colour_min, Colour_max);
    return colour_data;
}

/*NO MAPPING: Function to write store colour channel values in input RGBC struct into
 *  input string buffer:*/
void store_raw_colours(char *ColourToSend, Colour_data *colour_data)
{
    colour_data = colour_read_All(colour_data);
    sprintf(ColourToSend, "R:%04d G:%04d B:%04d C:%04d \r", 
            colour_data->R, colour_data->G, colour_data->B, colour_data->C);
}

/*MAPPING: Function to write store mapped colour channel values in input RGBC struct into
 *  input string buffer:*/
void store_mapped_colours(char *ColourToSend, Colour_data *colour_data, Colour_calib *colour_calib)
{
    colour_data = colour_map_All(colour_data, colour_calib);
    
    sprintf(ColourToSend, "R:%d%% G:%d%% B:%d%% \r", 
            colour_data->R, colour_data->G, colour_data->B);
}

/*Function to calibrate photodiode to different light conditions
 *maps colour channel values to within a predefined min-max range.
 */
void calib_colour(unsigned char *startup, char *CalibToSend, Colour_data *colour_data, Colour_calib *colour_calib)
{
    //define variables:
    bool flash = 1; //define variable to flashing status
    bool inrange;   //define variable to show distance status
    unsigned char Red = 0b100;  //variable emit red light
    unsigned char D_Green = 0b010;  //variable emit dark green light
    unsigned char L_Blue = 0b011;  //variable emit light blue light
    unsigned char D_Blue = 0b001;  //variable emit dark blue light
    unsigned char White = 0b111;  //variable emit white light
    unsigned char Off = 0b000;  //variable emit nothing
        
    while (*startup > 0){ //only run on startup
        while (*startup == 1){  //stage 1: show dark blue card
            if (flash){ //flash dark blue only once in this stage:
            RGB_flash (D_Blue, 3);
            flash = 0;
            }
            if (!BUTTON1){  //if button1 is pressed...
                flash = 1;  //turn on flash status
                //set Bmax to the blue value of the dark blue card:
                colour_calib->B_max =  colour_read_Blue(1);
                //set the optimal clear value (clear value at this setting):
                colour_calib->optimal_Clear_Val = colour_read_Clear(1);
                __delay_ms(100);
                *startup = 2;   //go into next stage
            }
        }
        while (*startup == 2){  //stage 2: show dark green card
            //Ensure correct distance is achieved to reach same optimal clear.
            inrange = distance_check(colour_calib); /*check reading range communicate to
                                         *user  using lights on buggy*/
            if (flash){ //flash green only once in this stage:
            RGB_flash (D_Green, 3);
            flash = 0;
            }
            if (!BUTTON1){
                flash = 1;  //turn on flash status
                if (inrange){   //only read values if within correct range:
                    //set Gmax to the green value of the dark green card:
                    colour_calib->G_max = colour_read_Green(1);
                    __delay_ms(100);
                    *startup = 3;   //go into next stage
                }
            }
        }
        while (*startup == 3){  //stage 3: show red card
            //Ensure correct distance is achieved to reach same optimal clear.
            inrange = distance_check(colour_calib); /*check reading range communicate to
                                         *user  using lights on buggy*/
            if (flash){ //flash red only once in this stage:
            RGB_flash (Red, 3);
            flash = 0;
            }
            if (!BUTTON1){  //if button1 is pressed...
                flash = 1;  //turn on flash status
                if (inrange){   //only read values if within correct range:
                    //set Rmax to the red value of the red card:
                    colour_calib->R_max = colour_read_Red(1);
                    __delay_ms(100);
                    //set Gmin to the green value of the red card:
                    colour_calib->G_min = colour_read_Green(1);
                    __delay_ms(100);
                    //set Bmin to the blue value of the red card:
                    colour_calib->B_min = colour_read_Blue(1);
                    __delay_ms(100);
                    *startup = 4;   //go into next stage
                }
            }
        }
        while (*startup == 4){  //stage 4: show light blue card
            //Ensure correct distance is achieved to reach same optimal clear.
            inrange = distance_check(colour_calib); /*check reading range communicate to
                                         *user  using lights on buggy*/
            if (flash){ //flash light blue only once in this stage:
            RGB_flash (L_Blue, 3);
            flash = 0;
            }
            if (!BUTTON1){
                flash = 1;  //turn on flash status
                if (inrange){   //only read values if within correct range:
                    //set Rmin to the red value of the light blue card:
                    colour_calib->R_min =  colour_read_Red(1);
                    __delay_ms(100);    //.1s delay
                    RGB_cycle(6);   /*emit all colours to show calibration
                                     *  completion*/
                    RGB_emit(White);    //emit white light for rest of code
                    *startup = 0;   //leave calibration loop
                    __delay_ms(2000); //2 seconds to move cards out of the way.
                }
            }
        }
    }
    
//Store calibration data in buffer (used for sending to serial)
    sprintf(CalibToSend, //Send colour bounds to PC:
              "Rmin:%04d Gmin:%04d Bmin:%04d Rmax:%04d Gmax:%04d Bmax:%04d\r", 
                colour_calib->R_min, colour_calib->G_min, colour_calib->B_min,
                colour_calib->R_max, colour_calib->G_max, colour_calib->B_max);
}


//Function to check clear channel value to ensure measurement at correct distance:
bool distance_check(Colour_calib *colour_calib)
{
    int C = colour_read_Clear(1);  //read clear channel value
    //Measure whether buggy is too close or too far
    bool too_far = C < (colour_calib->optimal_Clear_Val + leeway);
    bool too_close = C > (colour_calib->optimal_Clear_Val - leeway);
    //both include correct location, so use "and" operator.
    bool inrange = too_close & too_far;
    LED2 = too_close;  /*turn on LED1 if less than optimal Val*/                                                
    LED1 = too_far;  /*turn on LED2 if more *than optimal Val*/
                                                           
    //^else, turn both LED1 & LED2 on when in correct range
    return inrange;
}

//Function to identify the colours from the RGB readings from unknown card
//Data analysis through serial communication for accurate numbers
void colour_identify(char *ColourToSend, Colour_data *colour_data,  
                                                Colour_calib *colour_calib)
{
    //Read and map all raw colour values
    colour_data = colour_map_All(colour_data, colour_calib);
    //Store mapped values in shorter variables
    int R = colour_data->R;
    int G = colour_data->G;
    int B = colour_data->B;
    int C = colour_data->C;
    //Define array with possible colours and other commands
    char colour_arr[12][20] = {"RED", "PINK", "ORANGE", "YELLOW", 
                               "LIGHT GREEN", "DARK GREEN", "LIGHT BLUE", 
                               "DARK BLUE", "PURPLE", "BLACK", 
                               "Move closer", "Move further away"};
    //indicate whether buggy is too close or too far.
    if (C < (colour_calib->optimal_Clear_Val - leeway)){
        colour_data->detected_colour = 10;
        LED1 = 1;
        LED2 = 0;
    }
    else if (C > (colour_calib->optimal_Clear_Val + leeway)){
        colour_data->detected_colour = 11;
        LED1 = 0;
        LED2 = 1;
    }
    //If buggy is within correct distance range for C optimal.
    //Recognise colour through R,G,B readings.
    else {
        LED1 = 1;
        LED2 = 1;
        if (R >= 60){
            if (R >= 97){colour_data->detected_colour = 0;} //colour is red
            else if (R < 80){colour_data->detected_colour = 3;} //colour is yellow
            else if (B > 7){colour_data->detected_colour = 1;}  //colour is pink
            else {colour_data->detected_colour = 2;}    //colour is orange
        }
        else if (G >= 70){
            if (G >= 95){colour_data->detected_colour = 5;} //colour is dark green
            else if (B < 70){colour_data->detected_colour = 4;} //colour is light green
            else {colour_data->detected_colour = 6;}    //colour is light blue
        }
        else if (B >= 96){colour_data->detected_colour = 7;}    //colour is dark blue
        else{
            if (R >= 44){colour_data->detected_colour = 8;} //colour is purple  
            else {colour_data->detected_colour = 9;}    //colour is black
        }
    }
    //Store detected colour in buffer for serial.
    sprintf(ColourToSend, "Detected Colour: %s\r",  //store colour in buffer
            colour_arr[colour_data->detected_colour]);
}

