#ifndef _DC_MOTOR_H
#define _DC_MOTOR_H

#include <xc.h>
#include <stdbool.h> 

#define _XTAL_FREQ 64000000
#define topspeed 100

struct DC_motor { //definition of DC_motor structure
    unsigned char power; //motor power, out of 100
    char direction; //motor direction, forward(1), reverse(0)
    unsigned char *dutyHighByte; //PWM duty high byte address
    unsigned char *dir_LAT; //LAT for dir pin
    char dir_pin; // pin number that controls direction on LAT
    int PWMperiod; //base period of PWM cycle
};

#define PWMcycle 99

//function prototypes
void initDCmotorsPWM(int PWMperiod); // function to setup PWM
void setMotorPWM(struct DC_motor *m);
void init_LeftMotor(struct DC_motor *m);
void init_RightMotor(struct DC_motor *m);
void stop(struct DC_motor *mL, struct DC_motor *mR);
void turnLeft(struct DC_motor *mL, struct DC_motor *mR);
void turnRight(struct DC_motor *mL, struct DC_motor *mR);
void goStraight(struct DC_motor *mL, struct DC_motor *mR, bool dir);
void pulseStraight(struct DC_motor *mL, struct DC_motor *mR, bool dir);
void goBackwards(struct DC_motor *mL, struct DC_motor *mR);
void turnAngle(struct DC_motor *mL, struct DC_motor *mR, unsigned int direction,
        unsigned int angle, unsigned int *turnConstantL, unsigned int *turnConstantR);
void calib_turn(unsigned int *turnConstantL, unsigned int *turnConstantR, struct DC_motor *mL,
        struct DC_motor *mR);
void colour_turn(bool mode, int colour, unsigned int *turnConstantL, unsigned int *turnConstantR,
        struct DC_motor *mL, struct DC_motor *mR);
void traceback(unsigned int memory_index, unsigned int colour_memory[],
        unsigned int time_memory[], unsigned int *turnConstantL, unsigned int *turnConstantR,
        struct DC_motor *mL, struct DC_motor *mR);
void battery_init(void);
int battery_getval(void);
#endif
