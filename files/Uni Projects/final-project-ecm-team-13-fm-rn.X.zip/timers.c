#include <xc.h>#include <xc.h>
#include "timers.h"

//define a counter with time period of 100ms that increments:
unsigned int seconds_counter;  /*define global variable seconds to be
                                 used across files (see timers.h)*/

/************************************************************************
 * FUNCTION to initialise 16 bit timer0:
*/
void Timer0_init(void)
{
    T0CON1bits.T0CS=0b010; // Fosc/4 (clock source)
    T0CON1bits.T0ASYNC=1; /* see datasheet errata - needed to ensure correct
                           * operation when Fosc/4 used as clock source*/
    T0CON1bits.T0CKPS = prescaler; //int prescaler defined in RunMode.h 
    T0CON0bits.T016BIT=1;	//16bit mode
	
    /*Alter the number of effective bits to reduce time overflow time:*/
    TMR0H = start_high; //int start_high defined in RunMode.h   
    TMR0L = start_low; //int start_low defined in RunMode.h 
    
    T0CON0bits.T0EN=1;	//start the timer
}

/************************************
 * Function to return the full 16bit timer value
 * Note TMR0L and TMR0H must be read in the correct order, or TMR0H will not contain the correct value
************************************/
unsigned int get16bitTMR0val(void)
{
    unsigned int low=TMR0L; //read low value first
    unsigned int high=TMR0H; //read higher value
    high=high<<8; //turn higher value into 16bit number with 0's in least significant bits.
    unsigned int total=low+high;//sum lower and higher to get total 16bit timer value
    return total;//return as output of function
}