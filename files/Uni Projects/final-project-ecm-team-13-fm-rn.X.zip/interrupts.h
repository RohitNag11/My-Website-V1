
#ifndef _interrupts_H
#define _interrupts_H

#include <xc.h>
#include <stdbool.h> 

#define _XTAL_FREQ 64000000
//set up functions in interrupt.c
char stopforcard;
void Interrupts_init(unsigned int optimal_clear);
void ResetInterrupt(void);
void ClearInterrupt(void);
void __interrupt(low_priority) ColourISR();
void __interrupt(high_priority) TimerISR();

#endif





