#include <xc.h>
#include "math.h"

/********************************************//**
 *Function to project a value within a known range to inside a target range:
 * Used for colour mapping of RGB values
 ***********************************************/
int project_minmax(int x, int actual_min, int actual_max, 
                        int target_min, int target_max) 
{
  int temp = ((x - actual_min)*(target_max - target_min)/(actual_max - actual_min))
                                                                    + target_min;
  return temp;
}
