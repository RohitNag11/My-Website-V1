#ifndef _timers_H
#define _timers_H

//To overflow every 100ms.
#define prescaler (0b0101) //1:32
#define start_high (0b111100) //Most sig. bits to get to 11324 (8 highest bits)
#define start_low (0b10110000)//Least sig. bits to get to 11324 (8 lowest bits)

#include <xc.h>

#define _XTAL_FREQ 64000000

extern unsigned int (seconds_counter);

void Timer0_init(void);
unsigned int get16bitTMR0val(void);

#endif
